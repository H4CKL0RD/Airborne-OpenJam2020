gdjs.Lag_32CompensationCode = {};
gdjs.Lag_32CompensationCode.GDplayerObjects1= [];
gdjs.Lag_32CompensationCode.GDplayerObjects2= [];

gdjs.Lag_32CompensationCode.conditionTrue_0 = {val:false};
gdjs.Lag_32CompensationCode.condition0IsTrue_0 = {val:false};
gdjs.Lag_32CompensationCode.condition1IsTrue_0 = {val:false};


gdjs.Lag_32CompensationCode.userFunc0x6aabf0 = function(runtimeScene) {
"use strict";
runtimeScene.ws = new WebSocket("ws://localhost:5000/ws");
const id = Math.floor(Math.random() * Math.floor(100000))
runtimeScene.player_id = id
runtimeScene.delayedEvents = []

runtimeScene.ws.onopen = function (event) {
    const data = {
        command: "NEW_PLAYER",
        player_id: runtimeScene.player_id,
        data: {
            x: 300,
            y: 300
        }
    }
    setTimeout(() => {
        runtimeScene.ws.send(JSON.stringify(data))
    }, 500); 
};

runtimeScene.ws.onmessage = function (event) {
    const e = JSON.parse(event.data)
    switch (e.command) {
        case "NEW_PLAYER":
            newPlayer(e)
            break;
        case "MOVEMENT":
            movement(e)
            break;
        case "REFRESH_PLAYER":
            refreshPlayers(e)
            break;
        default:
            console.log("unknown command: " + e.command)
    }
}

function newPlayer(event) {
    const p = createPlayer(event)
    if (runtimeScene.player_id !== p.player_id) {
        p.setColor("255;100;100")
        // New player, re-send my player's data
        const o = runtimeScene.getObjects("player").find((o) => o.player_id === runtimeScene.player_id)
        const update = {
            command: "REFRESH_PLAYER",
            player_id: runtimeScene.player_id,
            data: {
                x: o.getX(),
                y: o.getY()
            }
        }
        runtimeScene.ws.send(JSON.stringify(update))
    }
}

function refreshPlayers(event) {
    const o = runtimeScene.getObjects("player").find((o) => o.player_id === event.player_id)
    if (typeof o === "undefined") {
        const p = createPlayer(event)
        p.setColor("255;100;100")
    }
}

function createPlayer(event) {
    const player = runtimeScene.createObject("player")
    player.setX(event.data.x)
    player.setY(event.data.y)
    player.player_id = event.player_id
    player.positions = []
    
    player.movementPlan = {
        sentTime: Date.now(),
        currentTime: 0,
        duration: event.duration,
        x: {
            start: event.data.x,
            end: event.data.x
        },
        y: {
            start: event.data.y,
            end: event.data.y
        }
    }
    return player
}

function movement(event) {
    // We're using client-side prediction, don't update the player's own character
    if (runtimeScene.player_id === event.player_id) {
        return
    }
    
    const o = runtimeScene.getObjects("player").find((o) => o.player_id === event.player_id)
    if (typeof o === "undefined") {
        return
    }

    o.positions.push(event)
}
};
gdjs.Lag_32CompensationCode.eventsList0 = function(runtimeScene) {

{


gdjs.Lag_32CompensationCode.userFunc0x6aabf0(runtimeScene);

}


};gdjs.Lag_32CompensationCode.eventsList1 = function(runtimeScene) {

{


gdjs.Lag_32CompensationCode.eventsList0(runtimeScene);
}


};gdjs.Lag_32CompensationCode.userFunc0x82ccd8 = function(runtimeScene) {
"use strict";
function lerp(start, end, movementPlan) {
    return start + (end - start) * lerpProgress(movementPlan)
}

function lerpProgress(movementPlan) {
    return movementPlan.currentTime / movementPlan.duration
}

runtimeScene.getObjects("player").forEach((player) => {
    if (player.player_id === runtimeScene.player_id) {
        return 
    }

    const movementPlan = player.movementPlan

    const x = lerp(movementPlan.x.start, movementPlan.x.end, movementPlan)
    const y = lerp(movementPlan.y.start, movementPlan.y.end, movementPlan)
    player.setX(x)
    player.setY(y)

    movementPlan.currentTime += runtimeScene.getTimeManager().getElapsedTime()
    if (lerpProgress(movementPlan) < 1) {
        return
    }

    let newPosition = player.positions.shift()
    if (typeof newPosition === "undefined") {
        newPosition = {
            command: "MOVEMENT",
            data: {
                x: player.getX(),
                y: player.getY()
            }
        }
    }

    player.movementPlan = {
        duration: player.movementPlan.duration,
        sentTime: newPosition.data.t,
        currentTime: 0,
        x: {
            start: movementPlan.x.end,
            end: newPosition.data.x
        },
        y: {
            start: movementPlan.y.end,
            end: newPosition.data.y
        }
    }
})
};
gdjs.Lag_32CompensationCode.eventsList2 = function(runtimeScene) {

{


gdjs.Lag_32CompensationCode.userFunc0x82ccd8(runtimeScene);

}


};gdjs.Lag_32CompensationCode.userFunc0x6d1be0 = function(runtimeScene) {
"use strict";
const input = runtimeScene._runtimeGame.getInputManager()
const player = runtimeScene.getObjects("player").find((o) => o.player_id === runtimeScene.player_id)

if (typeof player === "undefined") {
    return 
}

const movementSpeed = 0.33 * runtimeScene.getTimeManager().getElapsedTime()

let x = player.getX()
let y = player.getY()
let moved = false
if (input.isKeyPressed(37)) {
    moved = true
    x -= movementSpeed
}

if (input.isKeyPressed(39)) {
    moved = true
    x += movementSpeed
}

if (input.isKeyPressed(38)) {
    moved = true
    y -= movementSpeed
}

if (input.isKeyPressed(40)) {
    moved = true
    y += movementSpeed
}

if (moved === false) {
    return
}

player.setX(x)
player.setY(y)

const update = {
        command: "MOVEMENT",
        player_id: runtimeScene.player_id,
        data: {
            x: x,
            y: y
        }
}
runtimeScene.ws.send(JSON.stringify(update))
};
gdjs.Lag_32CompensationCode.eventsList3 = function(runtimeScene) {

{


gdjs.Lag_32CompensationCode.userFunc0x6d1be0(runtimeScene);

}


};gdjs.Lag_32CompensationCode.eventsList4 = function(runtimeScene) {

{


gdjs.Lag_32CompensationCode.condition0IsTrue_0.val = false;
{
gdjs.Lag_32CompensationCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Lag_32CompensationCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Lag_32CompensationCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.Lag_32CompensationCode.eventsList2(runtimeScene);
}


{


gdjs.Lag_32CompensationCode.eventsList3(runtimeScene);
}


};

gdjs.Lag_32CompensationCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Lag_32CompensationCode.GDplayerObjects1.length = 0;
gdjs.Lag_32CompensationCode.GDplayerObjects2.length = 0;

gdjs.Lag_32CompensationCode.eventsList4(runtimeScene);
return;

}

gdjs['Lag_32CompensationCode'] = gdjs.Lag_32CompensationCode;
