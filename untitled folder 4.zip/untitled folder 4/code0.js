gdjs.BasicCode = {};
gdjs.BasicCode.GDplayerObjects1= [];
gdjs.BasicCode.GDplayerObjects2= [];

gdjs.BasicCode.conditionTrue_0 = {val:false};
gdjs.BasicCode.condition0IsTrue_0 = {val:false};
gdjs.BasicCode.condition1IsTrue_0 = {val:false};


gdjs.BasicCode.userFunc0x7f1a88 = function(runtimeScene) {
"use strict";
runtimeScene.ws = new WebSocket("ws://localhost:5000/ws");
const id = Math.floor(Math.random() * Math.floor(100000))
runtimeScene.player_id = id
runtimeScene.delayedEvents = []

runtimeScene.ws.onopen = function (event) {
    const data = {
        command: "NEW_PLAYER",
        player_id: runtimeScene.player_id,
        data: {
            x: 300,
            y: 300
        }
    }
    setTimeout(() => {
        runtimeScene.ws.send(JSON.stringify(data))
    }, 500); 
};

runtimeScene.ws.onmessage = function (event) {
    const e = JSON.parse(event.data)
    switch (e.command) {
        case "NEW_PLAYER":
            newPlayer(e)
            break;
        case "MOVEMENT":
            movement(e)
            break;
        case "REFRESH_PLAYER":
            refreshPlayers(e)
            break;
        default:
            console.log("unknown command: " + e.command)
    }
}

function newPlayer(event) {
    const p = createPlayer(event)
    if (runtimeScene.player_id !== p.player_id) {
        p.setColor("255;100;100")
        // New player, re-send my player's data
        const o = runtimeScene.getObjects("player").find((o) => o.player_id === runtimeScene.player_id)
        const update = {
            command: "REFRESH_PLAYER",
            player_id: runtimeScene.player_id,
            data: {
                x: o.getX(),
                y: o.getY()
            }
        }
        runtimeScene.ws.send(JSON.stringify(update))
    }
}

function refreshPlayers(event) {
    const o = runtimeScene.getObjects("player").find((o) => o.player_id === event.player_id)
    if (typeof o === "undefined") {
        const p = createPlayer(event)
        p.setColor("255;100;100")
    }
}

function createPlayer(event) {
    const player = runtimeScene.createObject("player")
    player.setX(event.data.x)
    player.setY(event.data.y)
    player.player_id = event.player_id
    player.positions = []
    return player
}

function movement(event) {
    const o = runtimeScene.getObjects("player").find((o) => o.player_id === event.player_id)
    if (typeof o === "undefined") {
        return
    }

    o.setX(event.data.x)
    o.setY(event.data.y)
}
};
gdjs.BasicCode.eventsList0 = function(runtimeScene) {

{


gdjs.BasicCode.userFunc0x7f1a88(runtimeScene);

}


};gdjs.BasicCode.eventsList1 = function(runtimeScene) {

{


gdjs.BasicCode.eventsList0(runtimeScene);
}


};gdjs.BasicCode.userFunc0x6ca338 = function(runtimeScene) {
"use strict";
const input = runtimeScene._runtimeGame.getInputManager()
const player = runtimeScene.getObjects("player").find((o) => o.player_id === runtimeScene.player_id)

if (typeof player === "undefined") {
    return 
}

const movementSpeed = 0.33 * runtimeScene.getTimeManager().getElapsedTime()

let x = player.getX()
let y = player.getY()
let moved = false

if (input.isKeyPressed(37)) {
    moved = true
    x -= movementSpeed
}

if (input.isKeyPressed(39)) {
    moved = true
    x += movementSpeed
}

if (input.isKeyPressed(38)) {
    moved = true
    y -= movementSpeed
}

if (input.isKeyPressed(40)) {
    moved = true
    y += movementSpeed
}

if (moved === false) {
    return
}

const update = {
        command: "MOVEMENT",
        player_id: runtimeScene.player_id,
        data: {
            x: x,
            y: y
        }
}
runtimeScene.ws.send(JSON.stringify(update))
};
gdjs.BasicCode.eventsList2 = function(runtimeScene) {

{


gdjs.BasicCode.userFunc0x6ca338(runtimeScene);

}


};gdjs.BasicCode.eventsList3 = function(runtimeScene) {

{


gdjs.BasicCode.condition0IsTrue_0.val = false;
{
gdjs.BasicCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.BasicCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.BasicCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.BasicCode.eventsList2(runtimeScene);
}


};

gdjs.BasicCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.BasicCode.GDplayerObjects1.length = 0;
gdjs.BasicCode.GDplayerObjects2.length = 0;

gdjs.BasicCode.eventsList3(runtimeScene);
return;

}

gdjs['BasicCode'] = gdjs.BasicCode;
